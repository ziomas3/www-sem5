<?php
include "0begin.php";
?>
<h1>Zadanie 1 z Listy 6</h1>

<?php


$imie=$_POST["imie"];
isset($imie) or $imie=$_GET["imie"];
$nazwisko=$_POST["nazwisko"];
isset($nazwisko) or $nazwisko=$_GET["nazwisko"];
$plec=$_POST["plec"];
isset($plec) or $plec=$_GET["plec"];
$wzrost=$_POST["wzrost"];
isset($wzrost) or $plec=$_GET["wzrost"];
$urodzenie=$_POST["urodzenie"];
isset($urodzenie) or $plec=$_GET["urodzenie"];
$koment=$_POST["koment"];
isset($koment) or $plec=$_GET["koment"];

?>
<h1>Czat</h1>

<form method=post id="formularz">
Imie:<input type ="text" name="imie" value=<?=$imie?> ><br>
Nazwisko:<input type ="text" name="nazwisko" value=<?=$nazwisko?>><br>
Płeć: <br>
	<input type="radio" name="plec" value="mezczyzna" checked> Mężczyzna<br>
	<input type="radio" name="plec" value="kobieta"> Kobieta<br>
	<input type="radio" name="plec" value="inne"> Inna<br>
Wzrost:<input type ="number" name="wzrost" value=<?=$wzrost?>><br>
Urodzony:<select  name="urodzenie" >
	<option>Polska</option>
	<option>Inny kraj</option>
	
</select>

Komentarz:<textarea name="koment">Wpisz tutaj tekst...</textarea>

<input type="submit" value="wyślij">
</form>
<br><br>

<?php
If (!empty($imie))
{
echo "Imię: $_POST[imie]<br>";
echo "Nazwisko: $_POST[nazwisko]<br>";
echo "Płeć: $_POST[plec]<br>";
echo "Wzrost: $_POST[wzrost]<br>";
echo "Urodzony: $_POST[urodzenie]<br>";
echo "Komentarz: $_POST[koment]<br>";
}
include "0end.php";

