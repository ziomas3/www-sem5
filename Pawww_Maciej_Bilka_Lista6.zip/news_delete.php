<?php
include "0begin.php";
?>
<h1>Zadanie 4 z Listy 6</h1>

<?php
$art=$_POST["art"];
if( !empty($art))
rename("news/$art","news/.$art");
?>

<form method=post onsubmit="confirm('Czy jestes pewien?')">
Artykuł:<select  name="art" >
	<?php
        $newsy=scandir('news');
        foreach($newsy as $plik)

        {
            if($plik[0]!='.')
            {
                echo ("<option>$plik</option>");
            }
        }
    ?>
</select>

<input type="submit" value="usun">
</form>
<br><br>

<?php


include "0end.php";

