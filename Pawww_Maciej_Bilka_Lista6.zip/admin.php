<?php
include "0begin.php";
?>
<h1>Zadanie 6 z Listy 6</h1>


<h1>Czat</h1>
<ul>
<li><a href="img_add.php">img_add </a></li>
<li><a href="img_delete.php">img_delete </a></li>
<li><a href="news_add.php">news_add </a></li>
<li><a href="news_delete.php">news_Delete</a></li>
<li><a href="index.php">strona glowna</a></li>
</ul>


<?php
include "0end.php";


