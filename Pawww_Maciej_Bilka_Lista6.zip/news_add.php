<?php
include "0begin.php";
?>
<h1>Zadanie 3 z Listy 6</h1>

<?php


$tytul=$_POST["tytul"];
$tresc=$_POST["tresc"];


?>

<form method=post id="formularz">
Tytuł:<input type ="text" name="tytul" value=<?=$imie?> ><br>
Treść:<textarea name="tresc"></textarea>

<input type="submit" value="wyślij">
</form>
<br><br>

<?php
$t=time();

if( !empty($tytul) and !empty($tresc) )
{
    $myfile = "news/$tytul.$t.html";
    $content = "<br><div><h2>$tytul</h2> $tresc</div>\n";
    file_put_contents($myfile,$content);
    echo ($myfile);
    echo ($content);
}


include "0end.php";

