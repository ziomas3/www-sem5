<?php
include "0begin.php";
?>
<h1>Newsy</h1>
<ul>
<?php

  $newsy=scandir('news');


  foreach($newsy as $plik)

  {if($plik[0]!='.')
     {
        echo file_get_contents( "news/$plik" );
       echo "\n\n";
     }
  }
?>
</ul>
<?php
include "0end.php";