<?php
include "0begin.php";
?>
<h1>Zadanie 2 z Listy 6</h1>
<ul>
<?php


$nick=$_POST["nick"];
isset($nick) or $nick=$_GET["nick"];
$msg=$_POST["msg"];

?>
<h1>Czat</h1>

<form method=post>
Nick:<input name="nick" value=<?=$nick?> ><br>
Msg:<input name="msg"><br>
<input type="submit">
</form>

<script>document.querySelectorAll("input")[<?= 0+isset($nick)?> ].focus()</script>
<?php

$txt=file_get_contents("czat.txt");

if( !empty($nick) and !empty($msg) )
	file_put_contents("czat.txt","<div><b>$nick</b>: $msg</div>\n".$txt);



echo htmlspecialchars(file_get_contents( "czat.txt" ));

?>
</ul>
<?php
include "0end.php";


