<form method=post action='login_commit.php'>
<input name=login>
<input name=password type=password>
<input type=submit>
</form>