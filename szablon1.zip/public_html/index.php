<?php
include "a1.php";
//header("location:a1.php");