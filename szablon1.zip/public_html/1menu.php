<div id='menu'>
<a href="a1.php">Jeden</a>
<a href="a2.php">Dwa</a>
<a href="a3.php">Trzy</a>
<a href="a4.php">Cztery</a>
<a href="a5.php">Pięć</a>
<a href="a6.php">Szósta</a>
</div>