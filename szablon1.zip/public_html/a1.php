<?php
include "0begin.php";
?>
<h1> Strona pierwsza </h1>

Zaczynamy o czegoś prostego.

<?php
include "0end.php";