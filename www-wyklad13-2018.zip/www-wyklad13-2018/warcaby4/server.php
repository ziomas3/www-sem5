<?php

  $baza=new SQLite3("plansza.db");
  $baza->query("create table if not exists ruch
                   (id integer primary key autoincrement, 
                    i1 integer, i2 integer, what char(1))");

  $last='b';  // kto wykonał ostatni ruch
  $numer=0;   // numer ostatniego ruchu po stronie klienta
 
  if($_POST)
  { 
    $numer=intval($_POST["numer"]);
    $id1=intval($_POST["id1"]); // skąd
    $id2=intval($_POST["id2"]); // dokąd 
    $what=$_POST['what'][0];    // jaki pionek
    $restart=$_POST["restart"]; // czy restart

    if($restart=='restart')
        $baza->query("delete from ruch");

    if($id1)
    {   
       $res=$baza->query("select what from ruch order by id desc limit 1");
            if($x=$res->fetchArray(true))
                 $last=$x['what']; // czyj był ostatni ruch ('a' czy 'b')

        if($last!=$what) // nie można ruszać dwa razy tym samym pionkiem
            $baza->query("insert into ruch(i1,i2,what) values('$id1','$id2','$what')");
    }
  }  

  $res=$baza->query("select what from ruch order by id desc limit 1");
     if($x=$res->fetchArray(true))
        $last=$x['what']; // czyj był ostatni ruch ('a' czy 'b')
        
  $wynik['kolej']=($last=='b'?'a':'b'); // czyja teraz kolej
  
  $wynik['numer']=$numer; // numer ostatniego ruchu po stronie klienta
   
  $wynik['ruchy']=array(); // początkowo pusta tablica ruchów

  $res=$baza->query("select * from ruch where id>$numer order by id");
  while($ruch=$res->fetchArray(true)) // pobierz nowe ruchy 
  {
    $wynik['numer']=$ruch['id']; // aktualizuj numer ostatniego ruchu
    $wynik['ruchy'][]=$ruch;     // dodaj na końcu tablicy ruchów
  }

  echo json_encode($wynik);   // wyślij wynik w formacie JSON
