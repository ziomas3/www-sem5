Stworzone z myślą o ludziach
