<?php
include "0begin.php";
?>
<h1>Strona trzecia</h1>
Poniżej  znajdzie sie rozwiązanie trzeciego ćwiczenia

<ul>
<?php

  $filmy=scandir('movies');

  foreach($filmy as $x)

  if($x[0]!='.')
     echo "<video width='320' height='240' controls>
  <source src='movies/$x' type='video/mp4'>
Your browser does not support the video tag.
</video>"; 

$nick=$_POST["nick"];
isset($nick) or $nick=$_GET["nick"];
$msg=$_POST["msg"];

?>
<h1>Czat</h1>

<form method=post>
Nick:<input name="nick" value=<?=$nick?> ><br>
Msg:<input name="msg"><br>
<input type="submit">
</form>

<script>document.querySelectorAll("input")[<?= 0+isset($nick)?> ].focus()</script>
<?php

$txt=file_get_contents("czat.txt");

if( !empty($nick) and !empty($msg) )
	file_put_contents("czat.txt","<div><b>$nick</b>: $msg</div>\n".$txt);


include "czat.txt";

?>
</ul>
<?php
include "0end.php";
