<?php
include "zad1.php";
//header("location:zad1.php");?>
