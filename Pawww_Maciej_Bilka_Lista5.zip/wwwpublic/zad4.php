<?php
include "0begin.php";
?>
<h1>Strona Czwarta</h1>
Poniżej  znajdzie sie rozwiązanie czwartego ćwiczenia

<ul>
<?php

for ($x = 0; $x <= 1000; $x++) {
    echo "$x, ";
} 
  
?>
</ul>
<?php
include "0end.php";
