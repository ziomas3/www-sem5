<div id='menu'>
<a href="zad1.php">zad1</a>
<a href="zad1b.php">zad1b</a>
<a href="zad2.php">zad2</a>
<a href="zad3.php">zad3</a>
<a href="zad4.php">zad4</a>
<a href="zad5.php">zad5</a>
<a href="zad6.php">zad6</a>
<a href="new/index.php">zad7</a>
</div>
