<!DOCTYPE html>
<html>
<head>
    <charset='utf-8'>
    <style>
	* {font-family:Arial,Tahoma,Sans}
        body {background:#eee;}
	h1 {font-weight:normal;font-size:3em}
        a {text-decoration:none}
	div#main {text-align:left;
	          max-width:700px;
	          margin:auto;
	          min-height:700px;
	          padding:10px
	}
	table {
		border: 2px solid blue;
		font-weight:bold;
		font-family: 'Times New Roman', Times, serif;
		background-color: goldenrod;
		color:fuchsia;
		text-align:center;
	}
    </style>
</head>
<body>
<div id=main>
<?php
include "1menu.php";